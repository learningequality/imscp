<?php



$mitgliedsart = $HTTP_GET_VARS['mitgliedsart'];
$funktion = $HTTP_GET_VARS['funktion'];
$anrede = $HTTP_GET_VARS['anrede'];
$vorname = $HTTP_GET_VARS['vorname'];
$nachname = $HTTP_GET_VARS['nachname'];
$hochschule = $HTTP_GET_VARS['hochschule'];
$institut = $HTTP_GET_VARS['institut'];
$strasse = $HTTP_GET_VARS['strasse'];
$plz = $HTTP_GET_VARS['plz'];
$ort = $HTTP_GET_VARS['ort'];
$land = $HTTP_GET_VARS['land'];
$email = $HTTP_GET_VARS['email'];
$interesse = $HTTP_GET_VARS['interesse'];
$nutzung = $HTTP_GET_VARS['nutzung'];
$erfahrungGIS = $HTTP_GET_VARS['erfahrungGIS'];
$erfahrungELearning = $HTTP_GET_VARS['erfahrungELearning'];
$erfahrungXML = $HTTP_GET_VARS['erfahrungXML'];
$intentionen = $HTTP_GET_VARS['intentionen'];

/*---Mail an Koordinator---*/
$mailToCoordinator = "$mitgliedsart\n$funktion\n$anrede\n$vorname\n$nachname\n$hochschule\n$institut\n$strasse\n$postleitzahl\n$ort\n$land\n$email\n$bemerkungen\n$interesse\n$nutzung\n$erfahrungGIS\n$erfahrungELearning\n$erfahrungXML\n$intentionen\n\n...m�chte sich als Mitglied registrieren.";
$fp = popen("/usr/lib/sendmail -t ","w"); 
fputs($fp, "To: tgrossma@geo.uzh.ch\n"); 
fputs($fp, "From: tgrossma@geo.uzh.ch \n"); 
fputs($fp, "Subject: $vorname $nachname m�chte Mitglied werden\n\n"); 
fputs($fp, $mailToCoordinator); 
pclose($fp);

/*---Mail an pot. Mitglied---*/
$mailToMember = "Ihre Anfrage bez�glich Mitgliedschaft ist bei uns eingegangen. Wir werden...";
$fp = popen("/usr/lib/sendmail -t ","w"); 
fputs($fp, "To: $email\n"); 
fputs($fp, "From: coordinator@gitta.info \n"); 
fputs($fp, "Subject: Ihre Anfrage bez�glich Mitgliedschaft\n\n"); 
fputs($fp, $mailToMember); 
pclose($fp);

$filename = "$vorname$nachname";
$sqlstring = "INSERT INTO mitglieder (mitgliedsart, funktion, anrede, vorname, nachname, hochschule, institut, strasse, plz, ort, land, email, bemerkungen) VALUES ('$mitgliedsart', '$funktion', '$anrede', '$vorname', '$nachname', '$hochschule', '$institut', '$strasse', '$postleitzahl', '$ort', '$land', '$email');";

if (!$handle = fopen("$filename.sql", "w")) {
	exit;
}
if (!fwrite($handle, $sqlstring)) {
	exit;
}
fclose($handle);
header ("Location: http://www.gitta.info/website/en/html_reg/association_application_confirmation.html");

?>
